<footer class="footer">

   <section class="box-container">

      <div class="box">
         <h3>Category</h3>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> women</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> men</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> kids</a>
         <a href="shop.php"> <i class="fas fa-angle-right"></i> gift item</a>
      </div>

      <div class="box">
         <h3>Payment</h3>
         <a href="#"> <i class="fa fa-cc-visa" aria-hidden="true"></i> visa</a>
         <a href="#"> <i class="fa fa-credit-card"></i> credit</a>
         <a href="#"> <i class="fa fa-cc-paypal"></i> payple</a>
         <a href="#"> <i class="fa fa-cc-mastercard"></i> mastercard</a>
      </div>

     

      <div class="box">
         <h3>Contact info</h3>
         <p> <i class="fas fa-phone"></i> +94-710-444-505 </p>
         <p> <i class="fas fa-fax"></i> +94-332-333-200 </p>
         <p> <i class="fas fa-envelope"></i>trendzaa@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> colombo 02, Sri lanka- 11730 </p>
      </div>

     

     

   </section>

   <p class="credit"> &copy; copyright @ <?= date('Y'); ?> by <span>trendzaa.co</span> | all rights reserved! </p>

</footer>